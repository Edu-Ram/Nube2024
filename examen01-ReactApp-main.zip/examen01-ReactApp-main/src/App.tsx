import React from 'react';
import GetGeneration from './components/GetGeneration';
import logo from './imgs/pokemon-logo.png'

const App = () => {
	return (

	<div className="container">
		<div>
		<img src={logo} alt="Pokemon Logo" className='logoPokemon'/>
		</div>
		<GetGeneration/>
	</div>
	);
}

export default App;