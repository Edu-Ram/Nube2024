import React, { useState, useEffect } from "react";
import axios from "axios";
import ModalEntrenador from "./ModalEntrenador";

interface Entrenador {
  _id:  string;
  nombre: string;
  apellido: string;
  sexo: string;
  lugarDeResidencia: string;
  urlFotoEntrenador: string;
}

interface DataResponse {
  data: Entrenador[] | { entrenadores: string };
}

const GetEntrenadores = () => {
  const [data, setData] = useState<Entrenador[] | null>(null);
  const [selectedTrainer, setSelectedTrainer] = useState<string | null>(null);

  const Obtener = async () => {
    try {
      const response = await axios.get<DataResponse>("http://localhost:5005/entrenadores");
      if (Array.isArray(response.data.data)) {
        setData(response.data.data);
      } else {
        setData([]);
      }
      console.log(response.data.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    Obtener();
  }, []);

  if (data === null) {
    return <div>Cargando...</div>;
  }

  if (data.length === 0) {
    return <div>No se han registrado entrenadores aún</div>;
  }

  const showModal = (entrenadorId: string) => {
    setSelectedTrainer(entrenadorId);
  };

  const handleCloseModal = () => {
    setSelectedTrainer(null);
  };

  return (
    <div className="entrenadores-container">
      {data.map((entrenador, index) => (
        <div key={index} className="card trainerCard" onClick={() => showModal(entrenador._id)}>
          <img
            src={entrenador.urlFotoEntrenador}
            alt=""
            className="card-img-top trainerImg"
          />
          <div className="card-body">
            <p className="card-text text-left">{entrenador.nombre}</p>
          </div>
        </div>
      ))}
      {selectedTrainer && (
        <ModalEntrenador
          show={true}
          handleClose={handleCloseModal}
          id={selectedTrainer}
        />
      )}
    </div>
  );
};

export default GetEntrenadores;
