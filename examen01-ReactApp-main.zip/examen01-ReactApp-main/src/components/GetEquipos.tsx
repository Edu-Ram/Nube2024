import React, { useState, useEffect } from "react";
import axios from "axios";
import ModalEquipo from "./ModalEquipo";

interface Equipo {
  _id: string;
  nombre: string;
  imagen: string;
  entrenador: string;
  pokemons: String[];
}

interface DataResponse {
  data: Equipo[] | { equipos: string };
}

const GetEquipos = () => {
  const [data, setData] = useState<Equipo[] | null>(null);
  const [selectedEquipo, setSelectedEquipo] = useState<string | null>(null);

  const Obtener = async () => {
    try {
      const response = await axios.get<DataResponse>("http://localhost:5005/equipos");
      if (Array.isArray(response.data.data)) {
        setData(response.data.data);
      } else {
        setData([]);
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    Obtener();
  }, []);

  if (data === null) {
    return <div>Cargando...</div>;
  }

  if (data.length === 0) {
    return <div>No se han registrado equipos aún</div>;
  }

  const showModal = (equipoId: string) => {
    setSelectedEquipo(equipoId);
  };

  const handleCloseModal = () => {
    setSelectedEquipo(null);
  };

  return (
    <div className="equipos-container">
      {data.map((equipo, index) => (
        <div key={index} className="card teamCard" onClick={() => showModal(equipo._id)}>
          <img
            src={equipo.imagen}
            alt=""
            className="card-img-top teamImg"
          />
          <div className="card-body">
            <p className="card-text text-center">{equipo.nombre}</p>
          </div>
        </div>
      ))}
      {selectedEquipo && (
        <ModalEquipo
          show={true}
          handleClose={handleCloseModal}
          id={selectedEquipo}
        />
      )}
    </div>
  );
};

export default GetEquipos;
