import React, { useState, useEffect } from "react";
import axios from "axios";
import ComboBox from "./Selector";
import MyModal from "./MyModal";

interface GenerationRoutes {
  [key: string]: string;
}

const generationRoute: GenerationRoutes = {
  primera: "offset=0&limit=151",
  segunda: "offset=151&limit=100",
  tercera: "offset=251&limit=135",
  cuarta: "offset=386&limit=107",
  quinta: "offset=493&limit=156",
};

const GetGeneration = () => {
  const [data, setData] = useState<any[]>([]);
  const [generacion, setGeneracion] = useState<string>('primera');
  const [selectedPokemon, setSelectedPokemon] = useState<string | null>(null); 

  // handleSelect de combobox
  const handleSelect = (selectedValue: string) => {
    setGeneracion(selectedValue);
  };

  useEffect(() => {
    const obtenerData = async () => {
      try {
        if (generacion && generationRoute[generacion]) {
          const response = await axios.get(`https://pokeapi.co/api/v2/pokemon?${generationRoute[generacion]}`);
          const jsonData = response.data.results;
          setData(jsonData);
        }
      } catch (error) {
        console.error(error);
      }
    };

    obtenerData();
  }, [generacion]);

  const obtenerNumeroPokemon = (url: string) => {
    const parts = url.split('/');
    return parts[parts.length - 2];
  };

  const showModal = (namePokemon: string) => {
    setSelectedPokemon(namePokemon);
  };

  const handleCloseModal = () => {
    setSelectedPokemon(null);
  };

  const capitalizeFirstLetter = (str: string) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  return (
    <div>
      <ComboBox onSelect={handleSelect} />
      <div className="grid-container">
        {data.map((pokemon: any) => (
          <div key={pokemon.name} className="card" onClick={() => showModal(pokemon.name)}>
            <img
              src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${obtenerNumeroPokemon(pokemon.url)}.png`}
              alt=""
              className="card-img-top"
            />
            <div className="card-body">
              <p className="card-text text-center">{capitalizeFirstLetter(pokemon.name)}</p>
            </div>
          </div>
        ))}
      </div>
      {selectedPokemon && (
        <MyModal
          show={true}
          handleClose={handleCloseModal}
          name={selectedPokemon}
        />
      )}
    </div>
  );
};

export default GetGeneration;
