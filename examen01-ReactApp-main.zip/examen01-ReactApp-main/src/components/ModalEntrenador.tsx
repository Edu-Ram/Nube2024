import React, { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";

interface MyModalProps {
  show: boolean;
  handleClose: () => void;
  id?: string;
}

interface Entrenador {
    nombre: string;
    apellido: string;
    sexo: string;
    lugarDeResidencia: string;
    urlFotoEntrenador: string;
  }

const ModalEntrenador: React.FC<MyModalProps> = ({ show, handleClose, id }: MyModalProps) => {
  const [entrenadorData, setEntrenadorData] = useState<Entrenador>({
    nombre: "",
    apellido: "",
    sexo: "",
    lugarDeResidencia: "",
    urlFotoEntrenador: ""
  });

  useEffect(() => {
    const obtenerData = async () => {
      try {
        if (id) {
          const response = await axios.get(`http://localhost:5005/entrenadores/${id}`);
          const entrenador = response.data.data;

          setEntrenadorData({
            nombre: entrenador.nombre,
            apellido: entrenador.apellido,
            sexo: entrenador.sexo,
            lugarDeResidencia: entrenador.lugarDeResidencia,
            urlFotoEntrenador: entrenador.urlFotoEntrenador
          });
        }
      } catch (error) {
        console.error(error);
      }
    };

    if (id) {
      obtenerData();
    }
  }, [id]);

  

  return (
    <Modal show={show} onHide={handleClose} centered scrollable>
      <Modal.Header closeButton>
        <Modal.Title>{entrenadorData.nombre}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="modalBody">
          <img src={entrenadorData.urlFotoEntrenador} alt={entrenadorData.nombre} className="pokeImgInd"/>
          <p> <span className="bold">Nombre:</span> {entrenadorData.nombre}</p>
          <p> <span className="bold">Apellido:</span> {entrenadorData.apellido}</p>
          <p> <span className="bold">Sexo:</span> {entrenadorData.sexo}</p>
          <p> <span className="bold">Lugar De Residencia:</span> {entrenadorData.lugarDeResidencia}</p>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalEntrenador;
