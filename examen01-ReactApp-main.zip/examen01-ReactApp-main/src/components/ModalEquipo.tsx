import React, { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";

interface MyModalProps {
  show: boolean;
  handleClose: () => void;
  id?: string;
}

interface Entrenador {
  _id: string;
  nombre: string;
  apellido: string;
  sexo: string;
  lugarDeResidencia: string;
  urlFotoEntrenador: string;
}

interface Pokemon {
  nombre: string;
  numPokedex: string;
}

interface Equipo {
  _id: string;
  nombre: string;
  imagen: string;
  entrenador: Entrenador;
  pokemons: Pokemon[];
}

const ModalEquipo: React.FC<MyModalProps> = ({ show, handleClose, id }: MyModalProps) => {
  const [equipoData, setEquipoData] = useState<Equipo>({
    _id: "",
    nombre: "",
    imagen: "",
    entrenador: {
      _id: "",
      nombre: "",
      apellido: "",
      sexo: "",
      lugarDeResidencia: "",
      urlFotoEntrenador: ""
    },
    pokemons: []
  });

  const obtenerNumeroPokemon = (url: string): string => {
    const match = url.match(/\/(\d+)\/$/);
    return match ? match[1] : '';
  };

  useEffect(() => {
    const obtenerData = async () => {
      try {
        if (id) {
          const responseEquipos = await axios.get(`http://localhost:5005/equipos/${id}`);
          const equipo = responseEquipos.data.data;

          const responseEntrenador = await axios.get(`http://localhost:5005/entrenadores/${equipo.entrenador}`);
          const entrenador = responseEntrenador.data.data;

          const pokemonsData: Pokemon[] = [];
          for (const pokemonName of equipo.pokemons) {
            const responsePokemon = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
            const numPokedexPokemon = obtenerNumeroPokemon(responsePokemon.data.forms[0].url);
            pokemonsData.push({
              nombre: pokemonName,
              numPokedex: numPokedexPokemon,
            });
          }

          setEquipoData({
            _id: equipo._id,
            nombre: equipo.nombre,
            imagen: equipo.imagen,
            entrenador: {
              _id: entrenador._id,
              nombre: entrenador.nombre,
              apellido: entrenador.apellido,
              sexo: entrenador.sexo,
              lugarDeResidencia: entrenador.lugarDeResidencia,
              urlFotoEntrenador: entrenador.urlFotoEntrenador,
            },
            pokemons: pokemonsData,
          });
        }
      } catch (error) {
        console.error(error);
      }
    };

    if (id) {
      obtenerData();
    }
  }, [id]);


  const capitalizeFirstLetter = (str: string) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  return (
    <Modal show={show} onHide={handleClose} centered scrollable>
      <Modal.Header closeButton>
        <Modal.Title>{equipoData.nombre}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="modalBody">
          <img src={equipoData.imagen} alt={equipoData.nombre} className="teamImgOnModal"/>
          <p><span className="bold">Nombre:</span> {equipoData.nombre}</p>
          <p><span className="bold">Entrenador:</span></p>
          <ul>
            <li><img src={equipoData.entrenador.urlFotoEntrenador} alt="" className="trainerImgOnModal"/></li>
            <li>Nombre: {equipoData.entrenador.nombre}</li>
            <li>Apellido: {equipoData.entrenador.apellido}</li>
            <li>Sexo: {equipoData.entrenador.sexo}</li>
            <li>Lugar de Residencia: {equipoData.entrenador.lugarDeResidencia}</li>
          </ul>
          <p><span className="bold">Pokemons:</span></p>
          <table>
            <tbody>

            {equipoData.pokemons.map((pokemon, index) => (
                <tr key={index}>
                <td><img className="pokeImgOnModal" src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.numPokedex}.png`} alt={pokemon.nombre} /></td>
                <td>{capitalizeFirstLetter(pokemon.nombre)}</td>
              </tr>
            ))}
            </tbody>
          </table>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalEquipo;
