import React, { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import axios from "axios";

interface MyModalProps {
  show: boolean;
  handleClose: () => void;
  name?: string;
}

interface Stats {
  numPokedex: string;
  name: string;
  imgUrl: string;
  height: string;
  weight: string;
  types: string[];
  movements: string[];
}

const MyModal: React.FC<MyModalProps> = ({ show, handleClose, name }: MyModalProps) => {
  const [statsPokemon, setStatsPokemon] = useState<Stats>({
    numPokedex: "",
    name: "",
    imgUrl: "",
    height: "",
    weight: "",
    types: [],
    movements: [],
  });

  useEffect(() => {
    const obtenerData = async () => {
      try {
        if (name) {
          const response = await axios.get(`https://pokeapi.co/api/v2/pokemon/${name}`);
          const pokemonData = response.data;

          const numPokedex = obtenerNumeroPokemon(pokemonData.id.toString());
          const imgUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${numPokedex}.png`;
          const types = pokemonData.types.map((type: any) => capitalizeFirstLetter(type.type.name));
          const movements = pokemonData.moves.map((move: any) => capitalizeFirstLetter(move.move.name));

          setStatsPokemon({
            numPokedex: numPokedex,
            name: capitalizeFirstLetter(pokemonData.name),
            imgUrl: imgUrl,
            height: pokemonData.height.toString(),
            weight: pokemonData.weight.toString(),
            types: types,
            movements: movements,
          });
        }
      } catch (error) {
        console.error(error);
      }
    };

    if (name) {
      obtenerData();
    }
  }, [name]);

  const obtenerNumeroPokemon = (id: string) => {
    return id;
  };

  const capitalizeFirstLetter = (str: string) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  };

  return (
    <Modal show={show} onHide={handleClose} centered scrollable>
      <Modal.Header closeButton>
        <Modal.Title>{statsPokemon.name}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="modalBody">
          <img src={statsPokemon.imgUrl} alt={statsPokemon.name} className="pokeImgInd"/>
          <p> <span className="bold">Height:</span> {statsPokemon.height}</p>
          <p> <span className="bold">Weight:</span> {statsPokemon.weight}</p>
          <p> <span className="bold">Types:</span> {statsPokemon.types.join(", ")}</p>
          <p className="bold">Movements:</p>
          <ul>
            {statsPokemon.movements.map((move: string, index: number) => (
              <li key={index}>{move}</li>
            ))}
          </ul>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="primary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default MyModal;
