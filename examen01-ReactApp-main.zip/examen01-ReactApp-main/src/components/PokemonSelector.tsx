import React, { useState, useEffect } from 'react';
import Select, { MultiValue, ActionMeta, components } from 'react-select';
import axios from 'axios';

interface PokemonOption {
  value: string;
  label: string;
  imageUrl: string;
}

interface PokemonSelectorProps {
  setPokemons: (pokemons: string[]) => void;
}

const PokemonSelector = ({ setPokemons }: PokemonSelectorProps) => {
  const [pokemonOptions, setPokemonOptions] = useState<PokemonOption[]>([]);
  const [selectedPokemons, setSelectedPokemons] = useState<MultiValue<PokemonOption>>([]);

  useEffect(() => {
    const fetchPokemon = async () => {
      try {
        const response = await axios.get('https://pokeapi.co/api/v2/pokemon?offset=0&limit=649');
        const options = response.data.results.map((pokemon: { name: string, url: string }) => {
          const pokemonId = pokemon.url.split('/').filter(Boolean).pop();
          return {
            value: pokemon.name,
            label: pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1),
            imageUrl: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemonId}.png`
          };
        });
        setPokemonOptions(options);
      } catch (error) {
        console.error(error);
      }
    };

    fetchPokemon();
  }, []);

  const handleChange = (selectedOptions: MultiValue<PokemonOption>, actionMeta: ActionMeta<PokemonOption>) => {
    if (selectedOptions.length <= 6) {
      setSelectedPokemons(selectedOptions);
      setPokemons(selectedOptions.map(option => option.value));
    } else {
      alert('Solo puedes seleccionar 6 pokemons como máximo');
    }
  };

  const customOption = (props: any) => (
    <components.Option {...props}>
      <img src={props.data.imageUrl} alt={props.data.label} style={{ width: 40, marginRight: 10 }} />
      {props.data.label}
    </components.Option>
  );

  return (
    <Select
      options={pokemonOptions}
      isMulti
      value={selectedPokemons}
      onChange={handleChange}
      placeholder="Selecciona hasta 6 Pokémon"
      noOptionsMessage={() => "No hay opciones"}
      components={{ Option: customOption }}
    />
  );
};

export default PokemonSelector;
