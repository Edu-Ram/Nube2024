import { useState } from 'react';

interface ComboBoxProps {
    onSelect: (value: string) => void;
  }

const ComboBox = ({ onSelect }: ComboBoxProps) => {
  const [selectedValue, setSelectedValue] = useState('');
  const options = [
    { value: "primera", label: "Primera Generación" },
    { value: "segunda", label: "Segunda Generación" },
    { value: "tercera", label: "Tercera Generación" },
    { value: "cuarta", label: "Cuarta Generación" },
    { value: "quinta", label: "Quinta Generación" }
  ];

  const HandleChange = (event: any) => {
    const selectedValue = event.target.value;
    setSelectedValue(selectedValue);
    onSelect(selectedValue);
  };

  return (
    <select onChange={HandleChange} className='comboBox'>
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
};

export default ComboBox;