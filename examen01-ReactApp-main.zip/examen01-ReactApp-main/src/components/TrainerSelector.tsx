import React, { useState, useEffect } from "react";
import axios from "axios";

interface Entrenador {
  _id: string;
  nombre: string;
  apellido: string;
  sexo: string;
  lugarDeResidencia: string;
  urlFotoEntrenador: string;
}

interface DataResponse {
  data: Entrenador[] | { entrenadores: string };
}

interface ComboBoxProps {
  setEntrenadorId: (id: string) => void;
}

function ComboBox({ setEntrenadorId }: ComboBoxProps) {
  const [entrenadores, setEntrenadores] = useState<Entrenador[] | null>(null);
  const [selectedTrainerId, setSelectedTrainerId] = useState<string>("");

  useEffect(() => {
    const obtenerEntrenadores = async () => {
      try {
        const response = await axios.get<DataResponse>("http://localhost:5005/entrenadores");
        if (Array.isArray(response.data.data)) {
          setEntrenadores(response.data.data);
        } else {
          setEntrenadores([]);
        }
      } catch (error) {
        console.error(error);
      }
    };

    obtenerEntrenadores();
  }, []);

  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const id = event.target.value;
    setSelectedTrainerId(id);
    setEntrenadorId(id);
  };

  if (entrenadores === null) {
    return <div className="label">Cargando...</div>;
  }

  if (entrenadores.length === 0) {
    return <div className="label"> No se han registrado entrenadores aún</div>;
  }

  return (
    <div>
      <select
        id="entrenadores"
        value={selectedTrainerId}
        onChange={handleSelectChange}
      >
        <option value="" disabled>
          --Seleccionar--
        </option>
        {entrenadores.map((entrenador) => (
          <option key={entrenador._id} value={entrenador._id}>
            {entrenador.nombre} {entrenador.apellido}
          </option>
        ))}
      </select>
    </div>
  );
}

export default ComboBox;
