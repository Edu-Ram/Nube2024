import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import NavBar from "./components/NavBar";

import App from './App';
import Entrenadores from './pages/Entrenadores';
import RegistrarEntrenador from './pages/RegistrarEntrenador';
import Equipos from './pages/Equipos';
import CrearEquipo from './pages/CrearEquipo';
import { BrowserRouter, Routes, Route } from 'react-router-dom'

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <BrowserRouter>
    <NavBar />
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/entrenadores" element={<Entrenadores />} />
      <Route path="/registrarEntrenador" element={<RegistrarEntrenador />} />
      <Route path="/equipos" element={<Equipos />} />
      <Route path="/crearEquipo" element={<CrearEquipo />} />
    </Routes>
  </BrowserRouter>
);