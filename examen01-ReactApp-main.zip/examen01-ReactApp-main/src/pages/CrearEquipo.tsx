import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ComboBox from '../components/TrainerSelector';
import PokemonSelector from '../components/PokemonSelector';

const EquipoForm = () => {
  const [nombre, setNombre] = useState('');
  const [imagen, setImagen] = useState('');
  const [entrenadorId, setEntrenadorId] = useState<string | null>(null);
  const [pokemons, setPokemons] = useState<string[]>([]);

  const navigate = useNavigate();

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!entrenadorId) {
      alert('Por favor, selecciona un entrenador');
      return;
    }
    const equipoData = {
      nombre,
      imagen,
      entrenador: entrenadorId,
      pokemons,
    };


    if (nombre === '' || imagen === '') {
      alert('Por favor, complete todos los campos');
      return;
    }

    try {
      const response = await axios.post('http://localhost:5005/equipos', equipoData);
      console.log(response.data);
      alert('Equipo creado con éxito!');
      navigate('/equipos');
    } catch (error) {
      console.error(error);
      alert('Error al crear equipo');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <table>
        <tbody>
          <tr>
            <td className="label">Nombre:</td>
            <td>
              <input type="text" value={nombre} onChange={(event) => setNombre(event.target.value)} />
            </td>
          </tr>
          <tr>
            <td className="label">Imagen:</td>
            <td>
              <input type="text" value={imagen} onChange={(event) => setImagen(event.target.value)} />
            </td>
          </tr>
          <tr>
            <td className="label">Entrenador:</td>
            <td>
              <ComboBox setEntrenadorId={setEntrenadorId} />
            </td>
          </tr>
          <tr>
            <td className="label">Pokémon:</td>
            <td>
              <PokemonSelector setPokemons={setPokemons} />
            </td>
          </tr>
        </tbody>
      </table>
      <button type="submit">Crear equipo</button>
    </form>
  );
};

export default EquipoForm;
