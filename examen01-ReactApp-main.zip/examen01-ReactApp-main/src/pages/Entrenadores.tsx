import React from 'react';
import GetEntrenadores from '../components/GetEntrenadores';
import {Link} from 'react-router-dom';

function Entrenadores() {
    return (
    <div className="container">
        <GetEntrenadores/>
        <div>
            <ul>
                <li className="nav-item btn btn-primary">
                    <Link to="/registrarEntrenador" className="nav-link">Registrar Entrenador</Link>
                </li>
            </ul>
        </div>
    </div>
    );
}

export default Entrenadores;