import GetEquipos from '../components/GetEquipos';
import {Link} from 'react-router-dom';

function Equipos() {
    return (
    <div className="container">
        <GetEquipos/>
        <div>
            <ul>
                <li className="nav-item btn btn-primary">
                    <Link to="/crearEquipo" className="nav-link">Crear Equipo</Link>
                </li>
            </ul>
        </div>
    </div>
    );
}

export default Equipos;