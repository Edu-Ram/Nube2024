import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EntrenadorForm = () => {
  const [nombre, setNombre] = useState('');
  const [apellido, setApellido] = useState('');
  const [sexo, setSexo] = useState('');
  const [lugarDeResidencia, setLugarDeResidencia] = useState('');
  const [urlFotoEntrenador, setUrlFotoEntrenador] = useState('');

  const navigate = useNavigate();

  const HandleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const entrenadorData = {
      nombre: String(nombre),
      apellido: String(apellido),
      sexo: String(sexo),
      lugarDeResidencia: String(lugarDeResidencia),
      urlFotoEntrenador: String(urlFotoEntrenador),
    };

    try {
      const response = await axios.post('http://localhost:5005/entrenadores', entrenadorData);
      console.log(response.data);
      alert('Entrenador creado con éxito!');
      navigate('/entrenadores');
    } catch (error) {
      if(nombre === '' || apellido === '' || sexo === '' || lugarDeResidencia === '' || urlFotoEntrenador === ''){
        alert('Por favor, complete todos los campos');
      } else{
        console.error(error);
        alert('Error al crear entrenador');
      }

      
    }
  };

  return (
    <form onSubmit={HandleSubmit}>
      <table>
        <tbody>
          <tr>
            <td className='label'>Nombre:</td>
            <td>
              <input type="text" value={nombre} onChange={(event) => setNombre(event.target.value)} />
            </td>
          </tr>
          <tr>
            <td className='label'>Apellido:</td>
            <td>
              <input type="text" value={apellido} onChange={(event) => setApellido(event.target.value)} />
            </td>
          </tr>
          <tr>
            <td className='label'>Sexo:</td>
            <td>
              <select value={sexo} onChange={(event) => setSexo(event.target.value)}>
                <option value="">Seleccione un sexo</option>
                <option value="Masculino">Masculino</option>
                <option value="Femenino">Femenino</option>
              </select>
            </td>
          </tr>
          <tr>
            <td className='label'>Lugar de residencia:</td>
            <td>
              <input type="text" value={lugarDeResidencia} onChange={(event) => setLugarDeResidencia(event.target.value)} />
            </td>
          </tr>
          <tr>
            <td className='label'>URL de la foto del entrenador:</td>
            <td>
              <input type="text" value={urlFotoEntrenador} onChange={(event) => setUrlFotoEntrenador(event.target.value)} />
            </td>
          </tr>
        </tbody>
      </table>
      <button type="submit">Crear entrenador</button>
    </form>
  );
};

export default EntrenadorForm;
